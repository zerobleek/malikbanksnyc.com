// Custom cursor movement
const cursor = document.getElementById('customCursor');
window.addEventListener('mousemove', e => {
  cursor.style.left = e.clientX + 'px';
  cursor.style.top = e.clientY + 'px';
});

// Projects list (update easily)
const projects = [
  {
    title: "Project One",
    description: "Brief description of what this project proved and built.",
    image: "assets/project1.jpg"
  },
  {
    title: "Project Two",
    description: "Another demonstration of my capability in X domain.",
    image: "assets/project2.jpg"
  }
  // Add or remove project objects as needed
];

const projectsGrid = document.getElementById('projectsGrid');
projects.forEach(proj => {
  const card = document.createElement('div');
  card.classList.add('project-card');
  card.innerHTML = `
    <img src="${proj.image}" alt="${proj.title}">
    <div class="project-info">
      <h3>${proj.title}</h3>
      <p>${proj.description}</p>
    </div>
  `;
  projectsGrid.append(card);
});

// Email form submission
document.getElementById('emailForm').addEventListener('submit', function(e) {
  e.preventDefault();
  const emailInput = document.getElementById('email');
  const email = emailInput.value.trim();
  if (!email) return;
  document.getElementById('formResponse').textContent = `Thanks for subscribing, ${email}!`;
  emailInput.value = '';
  // TODO: integrate with an email service provider (Mailchimp, Formspree, etc.)
});
