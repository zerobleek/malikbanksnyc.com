document.getElementById('emailForm').addEventListener('submit', function (e) {
  e.preventDefault();
  const email = document.getElementById('email').value;
  document.getElementById('formResponse').textContent = `Thanks for subscribing, ${email}!`;

  // TODO: Integrate with Mailchimp, Google Sheets or your backend API
  this.reset();
});
